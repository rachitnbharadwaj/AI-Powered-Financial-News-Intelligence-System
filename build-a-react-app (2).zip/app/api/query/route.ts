export async function POST(request: Request) {
  try {
    const { query } = await request.json()

    // Sample articles for querying
    const articles = [
      {
        id: "N1",
        title: "HDFC Bank announces 15% dividend, board approves stock buyback",
        content: "HDFC Bank's board has approved a 15% dividend and authorized a stock buyback program.",
        source: "BSE India",
      },
      {
        id: "N2",
        title: "RBI raises repo rate by 25bps to 6.75%, citing inflation concerns",
        content: "The Reserve Bank of India increased the repo rate by 25 basis points to 6.75%.",
        source: "RBI Official",
      },
      {
        id: "N3",
        title: "ICICI Bank opens 500 new branches",
        content: "ICICI Bank announced expansion with 500 new locations.",
        source: "NSE India",
      },
      {
        id: "N4",
        title: "Banking sector NPAs decline to 5-year low",
        content: "Banking sector shows strong performance with NPAs declining.",
        source: "Financial Times",
      },
    ]

    // Simple query matching logic
    const queryLower = query.toLowerCase()
    let queryType = "general"
    let filtered = articles

    if (queryLower.includes("hdfc") || queryLower.includes("icici") || queryLower.includes("sbi")) {
      queryType = "company"
      filtered = articles.filter(
        (a) => a.title.toLowerCase().includes("hdfc") || a.title.toLowerCase().includes("icici"),
      )
    } else if (queryLower.includes("banking") || queryLower.includes("sector")) {
      queryType = "sector"
      filtered = articles.filter((a) => a.title.toLowerCase().includes("bank"))
    } else if (queryLower.includes("rbi") || queryLower.includes("policy")) {
      queryType = "regulatory"
      filtered = articles.filter((a) => a.title.toLowerCase().includes("rbi") || a.title.toLowerCase().includes("rate"))
    } else if (queryLower.includes("interest rate") || queryLower.includes("impact")) {
      queryType = "impact"
      filtered = articles.filter(
        (a) => a.title.toLowerCase().includes("rate") || a.title.toLowerCase().includes("bank"),
      )
    }

    return Response.json({
      query,
      query_type: queryType,
      articles: filtered,
      count: filtered.length,
    })
  } catch (error) {
    return Response.json({ error: "Query failed" }, { status: 500 })
  }
}
