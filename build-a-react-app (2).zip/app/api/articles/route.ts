export async function GET() {
  try {
    // Return sample articles
    const articles = [
      {
        id: "N1",
        title: "HDFC Bank announces 15% dividend, board approves stock buyback",
        content:
          "HDFC Bank's board has approved a 15% dividend and authorized a stock buyback program. The move reflects strong capital position and commitment to shareholders.",
        source: "BSE India",
        published_date: new Date(Date.now() - 2 * 3600000).toISOString(),
        is_duplicate: false,
      },
      {
        id: "N2",
        title: "RBI raises repo rate by 25bps to 6.75%, citing inflation concerns",
        content:
          "The Reserve Bank of India increased the repo rate by 25 basis points to 6.75% in response to persistent inflation concerns. This is an unexpected move that signals a hawkish stance.",
        source: "RBI Official",
        published_date: new Date(Date.now() - 1 * 3600000).toISOString(),
        is_duplicate: false,
      },
      {
        id: "N3",
        title: "ICICI Bank opens 500 new branches across Tier-2 cities",
        content:
          "ICICI Bank announced expansion of its branch network with 500 new locations in Tier-2 cities, targeting underserved markets for financial inclusion.",
        source: "NSE India",
        published_date: new Date(Date.now() - 3 * 3600000).toISOString(),
        is_duplicate: false,
      },
      {
        id: "N4",
        title: "Banking sector NPAs decline to 5-year low, credit growth at 16%",
        content:
          "Banking sector shows strong performance with Non-Performing Assets declining to 5-year lows and credit growth accelerating to 16% annually.",
        source: "Financial Times",
        published_date: new Date(Date.now() - 4 * 3600000).toISOString(),
        is_duplicate: false,
      },
      {
        id: "N5",
        title: "Central bank increases policy rate 25 bps in surprise inflation fight",
        content:
          "In an unexpected move, the central bank raised the policy rate by 25 basis points to combat rising inflation pressures in the economy.",
        source: "Reuters",
        published_date: new Date(Date.now() - 0.5 * 3600000).toISOString(),
        is_duplicate: true,
      },
    ]

    return Response.json({ articles })
  } catch (error) {
    return Response.json({ error: "Failed to fetch articles" }, { status: 500 })
  }
}
