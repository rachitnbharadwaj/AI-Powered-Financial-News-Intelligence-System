export async function POST(request: Request) {
  try {
    const { articles } = await request.json()

    // Extract entities from articles
    const entities = []
    const impacts = []

    articles.forEach((article) => {
      const text = (article.title + " " + article.content).toLowerCase()

      // Company extraction
      if (text.includes("hdfc")) entities.push({ text: "HDFC Bank", type: "Company", confidence: 1.0 })
      if (text.includes("icici")) entities.push({ text: "ICICI Bank", type: "Company", confidence: 1.0 })
      if (text.includes("sbi")) entities.push({ text: "SBI", type: "Company", confidence: 1.0 })

      // Sector extraction
      if (text.includes("banking")) entities.push({ text: "Banking", type: "Sector", confidence: 0.95 })
      if (text.includes("financial")) entities.push({ text: "Financial Services", type: "Sector", confidence: 0.9 })

      // Regulator extraction
      if (text.includes("rbi")) entities.push({ text: "Reserve Bank of India", type: "Regulator", confidence: 1.0 })

      // Percentage extraction
      const percentages = article.content.match(/(\d+%)/g) || []
      percentages.forEach((pct) => {
        entities.push({ text: pct, type: "Percentage", confidence: 0.95 })
      })

      // Basis points extraction
      const bps = article.content.match(/(\d+)\s*(?:bps|basis points)/gi) || []
      bps.forEach((bp) => {
        entities.push({ text: bp, type: "BasisPoints", confidence: 0.98 })
      })

      // Stock impact mapping
      if (text.includes("hdfc"))
        impacts.push({ symbol: "HDFCBANK", type: "direct", confidence: 1.0, entity: "HDFC Bank" })
      if (text.includes("icici"))
        impacts.push({ symbol: "ICICIBANK", type: "direct", confidence: 1.0, entity: "ICICI Bank" })
      if (text.includes("sbi")) impacts.push({ symbol: "SBIN", type: "direct", confidence: 1.0, entity: "SBI" })

      // Sector-wide impacts
      if (text.includes("banking")) {
        impacts.push(
          { symbol: "HDFCBANK", type: "sector", confidence: 0.65, entity: "Banking" },
          { symbol: "ICICIBANK", type: "sector", confidence: 0.65, entity: "Banking" },
          { symbol: "SBIN", type: "sector", confidence: 0.65, entity: "Banking" },
        )
      }
    })

    // Remove duplicates
    const uniqueEntities = Array.from(new Map(entities.map((e) => [e.text, e])).values())
    const uniqueImpacts = Array.from(new Map(impacts.map((i) => [i.symbol + i.type, i]).values()))

    return Response.json({
      entities: uniqueEntities.slice(0, 15),
      impacts: uniqueImpacts.slice(0, 15),
    })
  } catch (error) {
    return Response.json({ error: "Entity extraction failed" }, { status: 500 })
  }
}
