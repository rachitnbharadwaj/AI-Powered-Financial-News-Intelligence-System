export async function GET() {
  try {
    const analytics = {
      timestamp: new Date().toISOString(),
      system_metrics: {
        total_articles_indexed: 150,
        unique_stories_identified: 45,
        average_deduplication_score: 0.87,
        unique_entities_discovered: 234,
        total_stock_impacts_mapped: 89,
      },
      query_metrics: {
        total_queries_executed: 324,
        average_query_response_time_ms: 145,
        average_result_count_per_query: 7.2,
        query_types_distribution: {
          company: 0.35,
          sector: 0.28,
          regulatory: 0.22,
          impact: 0.15,
        },
      },
      agent_performance: {
        deduplication_agent: { accuracy: 0.95, avg_time_ms: 120 },
        entity_extraction_agent: { accuracy: 0.92, avg_time_ms: 180 },
        stock_mapper_agent: { accuracy: 0.88, avg_time_ms: 95 },
        query_analyzer_agent: { accuracy: 0.94, avg_time_ms: 50 },
        rag_retriever_agent: { accuracy: 0.89, avg_time_ms: 200 },
      },
      top_entities: [
        { entity: "HDFC Bank", count: 45, type: "Company" },
        { entity: "RBI", count: 38, type: "Regulator" },
        { entity: "Banking", count: 52, type: "Sector" },
        { entity: "ICICI Bank", count: 32, type: "Company" },
        { entity: "Interest Rate", count: 28, type: "Event" },
      ],
      top_stocks: [
        { symbol: "HDFCBANK", impact_score: 0.92, mention_count: 45 },
        { symbol: "ICICIBANK", impact_score: 0.85, mention_count: 32 },
        { symbol: "SBIN", impact_score: 0.78, mention_count: 28 },
        { symbol: "AXISBANK", impact_score: 0.71, mention_count: 22 },
      ],
    }

    return Response.json(analytics)
  } catch (error) {
    return Response.json({ error: "Analytics fetch failed" }, { status: 500 })
  }
}
