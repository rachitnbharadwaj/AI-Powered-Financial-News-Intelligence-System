export async function POST(request: Request) {
  try {
    const { query_type, query, articles_data } = await request.json()

    const articles = articles_data || getSampleArticles()

    let results = []

    switch (query_type) {
      case "company":
        results = searchByCompany(query, articles)
        break
      case "sector":
        results = searchBySector(query, articles)
        break
      case "regulatory":
        results = searchByRegulatory(query, articles)
        break
      case "impact":
        results = searchByImpact(query, articles)
        break
      default:
        results = searchGeneral(query, articles)
    }

    return Response.json({
      query_type,
      query,
      results: results.slice(0, 10),
      result_count: results.length,
    })
  } catch (error) {
    return Response.json({ error: "Type-based search failed" }, { status: 500 })
  }
}

function searchByCompany(query: string, articles: any[]) {
  const companyMap: Record<string, string[]> = {
    hdfc: ["HDFC Bank", "Banking", "Financial"],
    icici: ["ICICI Bank", "Banking", "Financial"],
    sbi: ["SBI", "Banking", "Financial"],
    axis: ["Axis Bank", "Banking", "Financial"],
  }

  const companies = Object.entries(companyMap)
    .filter(([key]) => query.toLowerCase().includes(key))
    .flatMap(([_, keywords]) => keywords)

  return articles.filter((article) => {
    const text = (article.title + " " + article.content).toLowerCase()
    return companies.some((company) => text.includes(company.toLowerCase()))
  })
}

function searchBySector(query: string, articles: any[]) {
  const sectors = ["banking", "technology", "telecom", "auto", "energy", "financial"]
  const matchingSectors = sectors.filter((sector) => query.toLowerCase().includes(sector))

  if (matchingSectors.length === 0) return articles

  return articles.filter((article) => {
    const text = (article.title + " " + article.content).toLowerCase()
    return matchingSectors.some((sector) => text.includes(sector))
  })
}

function searchByRegulatory(query: string, articles: any[]) {
  const regulators = ["rbi", "sebi", "nse", "bse", "policy", "regulation"]

  return articles.filter((article) => {
    const text = (article.title + " " + article.content).toLowerCase()
    return regulators.some((reg) => text.includes(reg))
  })
}

function searchByImpact(query: string, articles: any[]) {
  const impactKeywords = ["rise", "fall", "surge", "decline", "increase", "decrease", "boost", "pressure"]

  return articles.filter((article) => {
    const text = (article.title + " " + article.content).toLowerCase()
    return impactKeywords.some((keyword) => text.includes(keyword))
  })
}

function searchGeneral(query: string, articles: any[]) {
  const terms = query.toLowerCase().split(" ")

  return articles.filter((article) => {
    const text = (article.title + " " + article.content).toLowerCase()
    return terms.some((term) => text.includes(term))
  })
}

function getSampleArticles() {
  return [
    {
      id: "N1",
      title: "HDFC Bank announces 15% dividend",
      content: "HDFC Bank declared dividend",
      source: "BSE",
      published_date: new Date().toISOString(),
    },
  ]
}
