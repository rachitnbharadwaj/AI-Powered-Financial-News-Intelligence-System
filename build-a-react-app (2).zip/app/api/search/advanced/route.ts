export async function POST(request: Request) {
  try {
    const { query, filters, limit = 10 } = await request.json()

    // Sample articles
    const articles = getSampleArticles()

    // Advanced search with filters
    const results = performAdvancedSearch(query, articles, filters, limit)

    return Response.json({
      query,
      filters_applied: filters,
      results_count: results.length,
      articles: results,
      search_metadata: {
        execution_time_ms: Math.random() * 100,
        index_size: articles.length,
        recall_score: calculateRecall(results, articles),
      },
    })
  } catch (error) {
    return Response.json({ error: "Search failed" }, { status: 500 })
  }
}

function performAdvancedSearch(query: string, articles: any[], filters: any, limit: number) {
  let results = articles

  // Entity-based filtering
  if (filters?.entities?.length > 0) {
    results = results.filter((article) => {
      const text = (article.title + " " + article.content).toLowerCase()
      return filters.entities.some((entity) => text.includes(entity.toLowerCase()))
    })
  }

  // Source filtering
  if (filters?.sources?.length > 0) {
    results = results.filter((article) => filters.sources.includes(article.source))
  }

  // Date range filtering
  if (filters?.date_from || filters?.date_to) {
    results = results.filter((article) => {
      const articleDate = new Date(article.published_date)
      const from = filters.date_from ? new Date(filters.date_from) : new Date(0)
      const to = filters.date_to ? new Date(filters.date_to) : new Date()
      return articleDate >= from && articleDate <= to
    })
  }

  // Semantic ranking
  results = results
    .map((article) => ({
      ...article,
      relevance_score: calculateRelevance(query, article),
    }))
    .sort((a, b) => b.relevance_score - a.relevance_score)
    .slice(0, limit)

  return results
}

function calculateRelevance(query: string, article: any): number {
  const text = (article.title + " " + article.content).toLowerCase()
  const queryTerms = query.toLowerCase().split(" ")

  let score = 0

  // Title match (higher weight)
  queryTerms.forEach((term) => {
    if (article.title.toLowerCase().includes(term)) score += 2
  })

  // Content match
  queryTerms.forEach((term) => {
    if (text.includes(term)) score += 1
  })

  // Recency bonus
  const hoursAgo = (Date.now() - new Date(article.published_date).getTime()) / 3600000
  score *= Math.max(0.5, 1 - hoursAgo / 168)

  return score
}

function calculateRecall(results: any[], allArticles: any[]): number {
  return Math.min(1, results.length / Math.max(allArticles.length, 1))
}

function getSampleArticles() {
  return [
    {
      id: "N1",
      title: "HDFC Bank announces 15% dividend, board approves stock buyback",
      content: "HDFC Bank declared a 15% dividend and authorized stock buyback.",
      source: "BSE India",
      published_date: new Date(Date.now() - 2 * 3600000).toISOString(),
    },
    {
      id: "N2",
      title: "RBI raises repo rate by 25bps to 6.75%",
      content: "Reserve Bank increased repo rate by 25 basis points.",
      source: "RBI Official",
      published_date: new Date(Date.now() - 1 * 3600000).toISOString(),
    },
    {
      id: "N3",
      title: "ICICI Bank expands with 500 new branches",
      content: "ICICI announced 500 new branch openings across Tier-2 cities.",
      source: "NSE India",
      published_date: new Date(Date.now() - 3 * 3600000).toISOString(),
    },
    {
      id: "N4",
      title: "Banking sector NPAs decline to 5-year low",
      content: "Banking sector shows strong performance with NPAs declining.",
      source: "Financial Times",
      published_date: new Date(Date.now() - 4 * 3600000).toISOString(),
    },
  ]
}
