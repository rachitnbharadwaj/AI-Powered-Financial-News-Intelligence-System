export async function POST(request: Request) {
  try {
    const { articles } = await request.json()

    // Simple deduplication logic
    const duplicates = []

    for (let i = 0; i < articles.length; i++) {
      for (let j = i + 1; j < articles.length; j++) {
        const a1 = articles[i]
        const a2 = articles[j]

        // Calculate similarity
        const titleSim = calculateSimilarity(a1.title, a2.title)
        const contentSim = calculateSimilarity(a1.content.substring(0, 500), a2.content.substring(0, 500))

        const combinedSim = titleSim * 0.4 + contentSim * 0.6

        if (combinedSim >= 0.75) {
          duplicates.push({
            article1_id: a1.id,
            article2_id: a2.id,
            similarity: combinedSim,
          })
        }
      }
    }

    const groups = groupDuplicates(articles, duplicates)

    return Response.json({
      duplicate_count: duplicates.length,
      unique_stories: groups.length,
      duplicate_groups: groups,
    })
  } catch (error) {
    return Response.json({ error: "Deduplication failed" }, { status: 500 })
  }
}

function calculateSimilarity(text1: string, text2: string): number {
  const longer = text1.length > text2.length ? text1 : text2
  const shorter = text1.length > text2.length ? text2 : text1

  if (longer.length === 0) return 1.0

  const editDistance = getEditDistance(longer, shorter)
  return (longer.length - editDistance) / longer.length
}

function getEditDistance(s1: string, s2: string): number {
  const costs = []
  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j
      } else if (j > 0) {
        let newValue = costs[j - 1]
        if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
          newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1
        }
        costs[j - 1] = lastValue
        lastValue = newValue
      }
    }
    if (i > 0) costs[s2.length] = lastValue
  }
  return costs[s2.length]
}

function groupDuplicates(articles: any[], duplicates: any[]): any[] {
  const groups = []
  const processed = new Set()

  articles.forEach((article) => {
    if (processed.has(article.id)) return

    const group = [article]
    processed.add(article.id)

    duplicates.forEach((dup) => {
      if (dup.article1_id === article.id && !processed.has(dup.article2_id)) {
        const dupArticle = articles.find((a) => a.id === dup.article2_id)
        if (dupArticle) {
          group.push(dupArticle)
          processed.add(dup.article2_id)
        }
      } else if (dup.article2_id === article.id && !processed.has(dup.article1_id)) {
        const dupArticle = articles.find((a) => a.id === dup.article1_id)
        if (dupArticle) {
          group.push(dupArticle)
          processed.add(dup.article1_id)
        }
      }
    })

    groups.push(group)
  })

  return groups
}
