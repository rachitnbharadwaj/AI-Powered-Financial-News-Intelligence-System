export async function POST(request: Request) {
  try {
    const { articles } = await request.json()

    // Orchestrate multi-agent pipeline
    const results = {
      pipeline_status: "processing",
      agents_executed: [],
      timestamp: new Date().toISOString(),
      articles_processed: articles.length,
    }

    // Agent 1: Deduplication
    const dedupResult = executeDedupAgent(articles)
    results.agents_executed.push({
      name: "DeduplicationAgent",
      status: "completed",
      unique_stories: dedupResult.groups.length,
      duplicates_found: dedupResult.duplicates,
    })

    const uniqueArticles = dedupResult.groups.map((g) => g[0])

    // Agent 2: Entity Extraction
    const entityResult = executeEntityAgent(uniqueArticles)
    results.agents_executed.push({
      name: "EntityExtractionAgent",
      status: "completed",
      entities_extracted: entityResult.total,
      unique_entities: entityResult.unique,
    })

    // Agent 3: Stock Mapping
    const stockResult = executeStockAgent(entityResult.entities)
    results.agents_executed.push({
      name: "StockMapperAgent",
      status: "completed",
      affected_stocks: stockResult.stocks.length,
      total_impacts: stockResult.impacts,
    })

    // Agent 4: Sentiment & Relevance Scoring
    const scoringResult = executeScoringAgent(uniqueArticles)
    results.agents_executed.push({
      name: "ScoringAgent",
      status: "completed",
      articles_ranked: scoringResult.ranked_count,
    })

    results.pipeline_status = "completed"
    results.summary = {
      unique_stories: dedupResult.groups.length,
      total_entities: entityResult.total,
      affected_stocks: new Set(stockResult.stocks).size,
      avg_relevance_score: (scoringResult.total_score / scoringResult.ranked_count).toFixed(2),
    }

    return Response.json(results)
  } catch (error) {
    return Response.json({ error: "Agent pipeline failed" }, { status: 500 })
  }
}

function executeDedupAgent(articles: any[]) {
  const groups = []
  const processed = new Set()

  articles.forEach((article) => {
    if (processed.has(article.id)) return
    const group = [article]
    processed.add(article.id)
    groups.push(group)
  })

  return { groups, duplicates: articles.length - groups.length }
}

function executeEntityAgent(articles: any[]) {
  const entities = []
  const uniqueSet = new Set()

  const keywordMap = {
    companies: ["HDFC", "ICICI", "SBI", "Axis"],
    sectors: ["Banking", "Technology", "Financial"],
    regulators: ["RBI", "SEBI", "NSE"],
  }

  articles.forEach((article) => {
    const text = (article.title + " " + article.content).toLowerCase()

    Object.entries(keywordMap).forEach(([type, keywords]) => {
      keywords.forEach((keyword) => {
        if (text.includes(keyword.toLowerCase())) {
          entities.push({ text: keyword, type, confidence: 0.9 })
          uniqueSet.add(keyword)
        }
      })
    })
  })

  return { entities, total: entities.length, unique: uniqueSet.size }
}

function executeStockAgent(entities: any[]) {
  const stocks = new Set()
  const impacts = []

  const stockMap: Record<string, string> = {
    HDFC: "HDFCBANK",
    ICICI: "ICICIBANK",
    SBI: "SBIN",
    Axis: "AXISBANK",
  }

  entities.forEach((entity) => {
    if (stockMap[entity.text]) {
      stocks.add(stockMap[entity.text])
      impacts.push({ symbol: stockMap[entity.text], confidence: 0.95 })
    }
  })

  return { stocks: Array.from(stocks), impacts: impacts.length }
}

function executeScoringAgent(articles: any[]) {
  let totalScore = 0

  articles.forEach((article) => {
    const recencyScore = calculateRecency(article.published_date)
    const contentScore = article.content.length / 1000
    const sourceScore = article.source === "RBI Official" ? 1.0 : 0.8

    const score = recencyScore * 0.3 + Math.min(contentScore, 1) * 0.3 + sourceScore * 0.4
    totalScore += score
  })

  return { ranked_count: articles.length, total_score: totalScore }
}

function calculateRecency(date: string): number {
  const hours = (Date.now() - new Date(date).getTime()) / 3600000
  return Math.max(1 - hours / 24, 0.1)
}
