export async function POST(request: Request) {
  try {
    const { query, articles } = await request.json()

    // Query Analysis Agent
    const queryAnalysis = analyzeQuery(query)

    // RAG Retrieval Agent
    const retrieved = performRAGRetrieval(query, articles, queryAnalysis)

    // Impact Assessment Agent
    const impacts = assessMarketImpact(retrieved)

    // Context Augmentation Agent
    const augmented = augmentContext(retrieved, queryAnalysis)

    return Response.json({
      query,
      query_analysis: queryAnalysis,
      retrieved_articles: retrieved,
      market_impacts: impacts,
      augmented_context: augmented,
      confidence_score: calculateConfidence(retrieved, impacts),
    })
  } catch (error) {
    return Response.json({ error: "Query analysis failed" }, { status: 500 })
  }
}

function analyzeQuery(query: string) {
  const lowerQuery = query.toLowerCase()

  let intent = "information"
  if (lowerQuery.includes("impact") || lowerQuery.includes("affect")) intent = "impact"
  if (lowerQuery.includes("predict") || lowerQuery.includes("forecast")) intent = "prediction"

  let scope = "general"
  if (lowerQuery.includes("company") || /hdfc|icici|sbi|axis/i.test(query)) scope = "company"
  if (lowerQuery.includes("sector") || /banking|technology|telecom/i.test(query)) scope = "sector"
  if (lowerQuery.includes("rbi") || lowerQuery.includes("regulatory")) scope = "regulatory"

  const entities = extractQueryEntities(query)

  return { intent, scope, entities, parsed_query: query }
}

function extractQueryEntities(query: string): string[] {
  const entities = []
  const patterns = {
    companies: ["HDFC", "ICICI", "SBI", "Axis"],
    sectors: ["Banking", "Technology", "Telecom"],
    regulators: ["RBI", "SEBI", "NSE"],
  }

  Object.values(patterns).forEach((group) => {
    group.forEach((entity) => {
      if (query.toLowerCase().includes(entity.toLowerCase())) {
        entities.push(entity)
      }
    })
  })

  return entities
}

function performRAGRetrieval(query: string, articles: any[], analysis: any) {
  const relevant = articles.filter((article) => {
    const text = (article.title + " " + article.content).toLowerCase()

    return (
      analysis.entities.some((entity) => text.includes(entity.toLowerCase())) ||
      query.split(" ").some((word) => word.length > 4 && text.includes(word.toLowerCase()))
    )
  })

  return relevant.slice(0, 5).map((article) => ({
    id: article.id,
    title: article.title,
    excerpt: article.content.substring(0, 200),
    relevance_score: 0.85,
    source: article.source,
  }))
}

function assessMarketImpact(articles: any[]) {
  return articles.map((article) => ({
    symbol: extractSymbol(article.title),
    impact_type: "positive" as const,
    impact_score: 0.75,
    affected_sectors: extractSectors(article.title),
  }))
}

function extractSymbol(text: string): string {
  if (text.toLowerCase().includes("hdfc")) return "HDFCBANK"
  if (text.toLowerCase().includes("icici")) return "ICICIBANK"
  if (text.toLowerCase().includes("sbi")) return "SBIN"
  if (text.toLowerCase().includes("axis")) return "AXISBANK"
  return "UNKNOWN"
}

function extractSectors(text: string): string[] {
  const sectors = []
  if (text.toLowerCase().includes("bank")) sectors.push("Banking")
  if (text.toLowerCase().includes("tech")) sectors.push("Technology")
  if (text.toLowerCase().includes("rate")) sectors.push("Financial Services")
  return sectors
}

function augmentContext(articles: any[], analysis: any) {
  return {
    temporal_context: "Recent market activity",
    entity_relationships: `${analysis.entities.length} key entities identified`,
    regulatory_context: "RBI policy under consideration",
    sentiment_summary: "Mixed sentiment with focus on regulatory impacts",
  }
}

function calculateConfidence(articles: any[], impacts: any[]): number {
  return Math.min(0.95, 0.5 + articles.length * 0.1 + impacts.length * 0.05)
}
