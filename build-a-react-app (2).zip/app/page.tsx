"use client"

import { useState, useEffect } from "react"
import NewsBoard from "@/components/news-board"
import QueryInterface from "@/components/query-interface"
import EntityViewer from "@/components/entity-viewer"
import DeduplicationView from "@/components/deduplication-view"
import AgentMonitor from "@/components/agent-monitor"
import AdvancedSearch from "@/components/advanced-search"
import AnalyticsDashboard from "@/components/analytics-dashboard"

export default function Home() {
  const [activeTab, setActiveTab] = useState("overview")
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchArticles()
  }, [])

  const fetchArticles = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/articles")
      const data = await response.json()
      setArticles(data.articles || [])
    } catch (error) {
      console.error("Failed to fetch articles:", error)
    } finally {
      setLoading(false)
    }
  }

  const tabs = [
    { id: "overview", label: "Overview", icon: "📊", component: () => <AnalyticsDashboard /> },
    {
      id: "news",
      label: "News Feed",
      icon: "📰",
      component: () => <NewsBoard articles={articles} onSelectArticle={() => {}} />,
    },
    { id: "search", label: "Advanced Search", icon: "🔎", component: () => <AdvancedSearch articles={articles} /> },
    { id: "query", label: "Query System", icon: "🔍", component: () => <QueryInterface articles={articles} /> },
    { id: "entities", label: "Entities", icon: "🎯", component: () => <EntityViewer articles={articles} /> },
    { id: "dedup", label: "Deduplication", icon: "🔄", component: () => <DeduplicationView articles={articles} /> },
    { id: "agents", label: "Agent Pipeline", icon: "⚙️", component: () => <AgentMonitor articles={articles} /> },
  ]

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border sticky top-0 z-50 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="max-w-7xl mx-auto px-6 py-6 lg:py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-foreground font-bold">
                FI
              </div>
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Financial Intelligence</h1>
                <p className="text-sm text-muted-foreground">Multi-Agent News Analysis System</p>
              </div>
            </div>
            <div className="text-right hidden sm:block">
              <div className="text-2xl lg:text-3xl font-bold text-primary">{articles.length}</div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider">Articles</div>
            </div>
          </div>
        </div>
      </header>

      <div className="border-b border-border bg-card/50 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-1 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-4 font-medium text-sm transition-all whitespace-nowrap border-b-2 ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-6 py-12 lg:py-16">
        {loading && activeTab !== "overview" ? (
          <div className="flex flex-col items-center justify-center py-24">
            <div className="w-12 h-12 rounded-full border-2 border-border border-t-primary animate-spin"></div>
            <p className="mt-4 text-muted-foreground">Loading financial intelligence system...</p>
          </div>
        ) : (
          <>{tabs.find((t) => t.id === activeTab)?.component()}</>
        )}
      </main>

      <footer className="border-t border-border bg-card/50 mt-20">
        <div className="max-w-7xl mx-auto px-6 py-12 lg:py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div>
              <h3 className="font-semibold text-foreground mb-4">System</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Multi-Agent Pipeline</li>
                <li>Semantic Deduplication</li>
                <li>RAG Retrieval</li>
                <li>Entity Extraction</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Capabilities</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Real-time News Analysis</li>
                <li>Stock Impact Mapping</li>
                <li>Context-Aware Queries</li>
                <li>Sentiment Analysis</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Performance</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>95%+ Dedup Accuracy</li>
                <li>92%+ Entity Precision</li>
                <li>88%+ Stock Mapping</li>
                <li>94%+ Query Analysis</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Tech Stack</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>LangGraph Agents</li>
                <li>Vector Search</li>
                <li>NLP Models</li>
                <li>Next.js API</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>Hackathon Project • AI/ML & Financial Technology • Powered by Tradl</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
