"""
Query Engine Module
Context-aware natural language query processing
"""

from typing import List, Dict
import re

class QueryEngine:
    """Process natural language queries and retrieve relevant articles"""
    
    def parse_query(self, query: str) -> Dict:
        """Parse query to extract intent and entities"""
        query_lower = query.lower()
        
        intent = "general"
        if "news" in query_lower or "update" in query_lower:
            intent = "news"
        elif "impact" in query_lower or "affect" in query_lower:
            intent = "impact"
        elif "policy" in query_lower:
            intent = "policy"
        
        # Extract potential entities
        entities = self._extract_query_entities(query)
        
        return {
            "original": query,
            "intent": intent,
            "entities": entities,
            "type": self._classify_query_type(query)
        }
    
    def _extract_query_entities(self, query: str) -> List[str]:
        """Extract entities mentioned in query"""
        entities = []
        
        company_pattern = r'(HDFC Bank|ICICI Bank|SBI|Axis Bank|Kotak|TCS|Infosys|Wipro)'
        entities.extend(re.findall(company_pattern, query, re.IGNORECASE))
        
        sector_pattern = r'(banking|technology|telecom|auto|energy|financial|sector)'
        if re.search(sector_pattern, query, re.IGNORECASE):
            sectors = re.findall(sector_pattern, query, re.IGNORECASE)
            entities.extend(sectors)
        
        regulator_pattern = r'(RBI|SEBI|NSE|BSE|RBI|central bank)'
        entities.extend(re.findall(regulator_pattern, query, re.IGNORECASE))
        
        return list(set(entities))
    
    def _classify_query_type(self, query: str) -> str:
        """Classify query as company-specific, sector-wide, or regulatory"""
        query_lower = query.lower()
        
        if any(company in query_lower for company in ['hdfc', 'icici', 'sbi', 'axis', 'kotak']):
            return "company"
        elif any(sector in query_lower for sector in ['banking', 'technology', 'telecom', 'sector']):
            return "sector"
        elif any(reg in query_lower for reg in ['rbi', 'sebi', 'policy', 'regulatory']):
            return "regulatory"
        
        return "general"
    
    def filter_by_query_type(self, articles: List[dict], query_type: str, entities: List[str]) -> List[dict]:
        """Filter articles based on query type and entities"""
        filtered = []
        
        for article in articles:
            article_text = (article['title'] + " " + article['content']).lower()
            
            if query_type == "company":
                # Match company-specific articles
                for entity in entities:
                    if entity.lower() in article_text:
                        filtered.append(article)
                        break
            
            elif query_type == "sector":
                # Match sector-wide articles
                for entity in entities:
                    if entity.lower() in article_text:
                        filtered.append(article)
                        break
            
            elif query_type == "regulatory":
                # Match regulatory/policy articles
                if any(keyword in article_text for keyword in entities):
                    filtered.append(article)
            
            else:
                # General match
                if any(entity.lower() in article_text for entity in entities):
                    filtered.append(article)
        
        return filtered
