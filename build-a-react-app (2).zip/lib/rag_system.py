"""
Retrieval Augmented Generation System
Vector embeddings and semantic search for financial news
"""

from typing import List, Dict, Tuple
import json
from dataclasses import dataclass, asdict
import numpy as np
from collections import defaultdict

@dataclass
class TextEmbedding:
    """Represents a text with its embedding vector"""
    text: str
    embedding: List[float]
    metadata: Dict

class SimpleEmbedder:
    """Simple embedding generator using TF-IDF-like approach"""
    
    def __init__(self):
        self.vocab = {}
        self.idf = {}
    
    def build_vocab(self, texts: List[str]):
        """Build vocabulary from texts"""
        doc_freq = defaultdict(int)
        
        for text in texts:
            words = set(text.lower().split())
            for word in words:
                doc_freq[word] += 1
        
        # Build IDF
        total_docs = len(texts)
        for word, freq in doc_freq.items():
            self.idf[word] = np.log((total_docs + 1) / (freq + 1))
        
        self.vocab = {word: idx for idx, word in enumerate(self.idf.keys())}
    
    def embed(self, text: str) -> List[float]:
        """Create embedding vector for text"""
        vector = np.zeros(len(self.vocab))
        words = text.lower().split()
        
        for word in words:
            if word in self.vocab:
                idx = self.vocab[word]
                vector[idx] = self.idf.get(word, 0)
        
        # Normalize
        norm = np.linalg.norm(vector)
        if norm > 0:
            vector = vector / norm
        
        return vector.tolist()

class VectorStore:
    """Simple in-memory vector store for semantic search"""
    
    def __init__(self):
        self.embeddings = []
        self.embedder = SimpleEmbedder()
    
    def index_documents(self, documents: List[Dict]):
        """Index documents with embeddings"""
        texts = [doc.get('title', '') + ' ' + doc.get('content', '') for doc in documents]
        
        # Build vocabulary
        self.embedder.build_vocab(texts)
        
        # Create embeddings
        for doc, text in zip(documents, texts):
            embedding = self.embedder.embed(text)
            self.embeddings.append({
                'id': doc['id'],
                'embedding': embedding,
                'metadata': doc
            })
    
    def search(self, query: str, top_k: int = 5) -> List[Tuple[Dict, float]]:
        """Semantic search for similar documents"""
        query_embedding = self.embedder.embed(query)
        scores = []
        
        for item in self.embeddings:
            # Cosine similarity
            similarity = self._cosine_similarity(query_embedding, item['embedding'])
            scores.append((item['metadata'], similarity))
        
        # Sort by similarity and return top-k
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]
    
    @staticmethod
    def _cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between vectors"""
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        mag1 = np.sqrt(sum(a * a for a in vec1))
        mag2 = np.sqrt(sum(b * b for b in vec2))
        
        if mag1 == 0 or mag2 == 0:
            return 0.0
        
        return dot_product / (mag1 * mag2)

class RAGSystem:
    """Complete RAG system for financial news"""
    
    def __init__(self):
        self.vector_store = VectorStore()
        self.deduplicator = None
    
    def initialize(self, articles: List[Dict]):
        """Initialize RAG system with articles"""
        # Index articles
        self.vector_store.index_documents(articles)
    
    def retrieve_relevant(self, query: str, top_k: int = 5) -> List[Dict]:
        """Retrieve relevant articles for a query"""
        results = self.vector_store.search(query, top_k)
        return [doc for doc, score in results]
    
    def augment_query_context(self, query: str) -> Dict:
        """Augment query with relevant context"""
        relevant_docs = self.retrieve_relevant(query, top_k=3)
        
        context = {
            'query': query,
            'relevant_documents': relevant_docs,
            'context_summary': self._summarize_context(relevant_docs)
        }
        
        return context
    
    @staticmethod
    def _summarize_context(documents: List[Dict]) -> str:
        """Create summary context from documents"""
        if not documents:
            return "No relevant context found."
        
        sources = [doc.get('source', 'Unknown') for doc in documents]
        titles = [doc.get('title', '')[:50] + '...' for doc in documents]
        
        summary = f"Found {len(documents)} relevant articles from sources: {', '.join(set(sources))}. "
        summary += "Key topics: " + " | ".join(titles)
        
        return summary
