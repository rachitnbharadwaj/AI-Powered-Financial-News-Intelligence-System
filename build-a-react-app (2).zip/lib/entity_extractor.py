"""
Entity Extraction Module
Extracts financial entities from news articles
"""

import re
from typing import List, Dict, Tuple
from dataclasses import dataclass

@dataclass
class Entity:
    text: str
    type: str
    confidence: float

class FinancialEntityExtractor:
    """Extract financial entities from text"""
    
    # Known Indian banks and companies
    COMPANIES = {
        "HDFC Bank": "Bank",
        "ICICI Bank": "Bank",
        "SBI": "Bank",
        "Axis Bank": "Bank",
        "Kotak Bank": "Bank",
        "TCS": "Technology",
        "Infosys": "Technology",
        "Wipro": "Technology",
        "Reliance": "Conglomerate",
        "ITC": "Conglomerate"
    }
    
    REGULATORS = {
        "RBI": "Reserve Bank of India",
        "Reserve Bank": "Reserve Bank of India",
        "SEBI": "Securities and Exchange Board",
        "NSE": "National Stock Exchange",
        "BSE": "Bombay Stock Exchange"
    }
    
    SECTORS = {
        "banking": ["Banking", "Financial Services"],
        "technology": ["Technology", "IT Services"],
        "telecom": ["Telecom", "Telecommunications"],
        "auto": ["Automotive", "Auto"],
        "energy": ["Energy", "Oil & Gas"]
    }
    
    def extract_entities(self, text: str) -> List[Entity]:
        """Extract all entities from text"""
        entities = []
        
        # Extract companies
        for company, sector in self.COMPANIES.items():
            if re.search(r'\b' + re.escape(company) + r'\b', text, re.IGNORECASE):
                entities.append(Entity(company, "Company", 1.0))
        
        # Extract regulators
        for regulator, full_name in self.REGULATORS.items():
            if re.search(r'\b' + re.escape(regulator) + r'\b', text, re.IGNORECASE):
                entities.append(Entity(full_name, "Regulator", 1.0))
        
        # Extract sectors
        for sector_keyword, sector_names in self.SECTORS.items():
            if re.search(r'\b' + sector_keyword + r'\b', text, re.IGNORECASE):
                for sector in sector_names:
                    entities.append(Entity(sector, "Sector", 0.9))
        
        # Extract numbers and percentages
        percentages = re.findall(r'(\d+(?:\.\d+)?%)', text)
        for pct in percentages:
            entities.append(Entity(pct, "Percentage", 0.8))
        
        basis_points = re.findall(r'(\d+)\s*(?:bps|basis points)', text, re.IGNORECASE)
        for bp in basis_points:
            entities.append(Entity(f"{bp}bps", "BasisPoints", 0.95))
        
        return entities

class StockImpactMapper:
    """Map entities to affected stocks"""
    
    STOCK_MAPPING = {
        "HDFC Bank": {"symbol": "HDFCBANK", "confidence": 1.0},
        "ICICI Bank": {"symbol": "ICICIBANK", "confidence": 1.0},
        "SBI": {"symbol": "SBIN", "confidence": 1.0},
        "Axis Bank": {"symbol": "AXISBANK", "confidence": 1.0},
        "Banking": {"symbols": ["HDFCBANK", "ICICIBANK", "SBIN", "AXISBANK"], "confidence": 0.65},
        "Technology": {"symbols": ["TCS", "INFY", "WIPRO"], "confidence": 0.60},
    }
    
    def map_stocks(self, entities: List[Entity], text: str) -> List[Dict]:
        """Map entities to impacted stocks"""
        impacts = []
        
        for entity in entities:
            if entity.text in self.STOCK_MAPPING:
                mapping = self.STOCK_MAPPING[entity.text]
                
                if "symbol" in mapping:
                    impacts.append({
                        "symbol": mapping["symbol"],
                        "confidence": mapping["confidence"],
                        "type": "direct",
                        "entity": entity.text
                    })
                elif "symbols" in mapping:
                    for symbol in mapping["symbols"]:
                        impacts.append({
                            "symbol": symbol,
                            "confidence": mapping["confidence"],
                            "type": "sector",
                            "entity": entity.text
                        })
        
        return impacts
