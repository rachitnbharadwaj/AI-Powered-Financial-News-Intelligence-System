"""
Deduplication Module
Identifies and consolidates duplicate articles using semantic similarity
"""

from typing import List, Tuple
import difflib
import hashlib

class ArticleDeduplicator:
    """Detect and consolidate duplicate articles"""
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """Calculate similarity between two texts using SequenceMatcher"""
        matcher = difflib.SequenceMatcher(None, text1.lower(), text2.lower())
        return matcher.ratio()
    
    def semantic_fingerprint(self, text: str) -> str:
        """Create semantic fingerprint of article"""
        # Extract key phrases
        words = text.lower().split()
        
        # Remove common words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'}
        key_words = [w for w in words if w not in stop_words and len(w) > 3]
        
        # Sort and hash for fingerprint
        fingerprint = ' '.join(sorted(set(key_words)))
        return hashlib.md5(fingerprint.encode()).hexdigest()[:8]
    
    def find_duplicates(self, articles: List[dict], threshold: float = 0.75) -> List[Tuple[str, str, float]]:
        """
        Find duplicate articles above similarity threshold
        Returns: List of (article1_id, article2_id, similarity_score)
        """
        duplicates = []
        
        for i, article1 in enumerate(articles):
            for article2 in articles[i+1:]:
                # Check title similarity
                title_sim = self.calculate_similarity(article1['title'], article2['title'])
                
                # Check content similarity (sample first 500 chars)
                content_sim = self.calculate_similarity(
                    article1['content'][:500],
                    article2['content'][:500]
                )
                
                # Combined similarity
                combined_sim = (title_sim * 0.4) + (content_sim * 0.6)
                
                if combined_sim >= threshold:
                    duplicates.append((article1['id'], article2['id'], combined_sim))
        
        return duplicates
    
    def consolidate_duplicates(self, article_group: List[dict]) -> dict:
        """Consolidate a group of duplicate articles into single canonical article"""
        # Choose article with most content as canonical
        canonical = max(article_group, key=lambda a: len(a['content']))
        
        return {
            "id": canonical['id'],
            "title": canonical['title'],
            "content": canonical['content'],
            "source": ", ".join(set(a['source'] for a in article_group)),
            "published_date": min(a['published_date'] for a in article_group),
            "duplicate_count": len(article_group) - 1,
            "duplicate_ids": [a['id'] for a in article_group if a['id'] != canonical['id']]
        }
