"""
LangGraph Multi-Agent System
Orchestrates multiple specialized agents for financial news analysis
"""

from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum

class AgentType(Enum):
    DEDUPLICATION = "deduplication"
    ENTITY_EXTRACTION = "entity_extraction"
    STOCK_MAPPER = "stock_mapper"
    QUERY_ANALYZER = "query_analyzer"
    RAG_RETRIEVER = "rag_retriever"

@dataclass
class AgentMessage:
    """Message passed between agents"""
    sender: str
    receiver: str
    task: str
    payload: Dict[str, Any]
    result: Any = None

class DeduplicationAgent:
    """Agent responsible for identifying duplicate articles"""
    
    def __init__(self, deduplicator):
        self.deduplicator = deduplicator
        self.name = "DeduplicationAgent"
    
    def process(self, articles: List[Dict]) -> Dict:
        """Process articles for duplicates"""
        duplicates = self.deduplicator.find_duplicates(articles, threshold=0.75)
        
        # Group duplicates
        groups = self._group_duplicates(articles, duplicates)
        
        return {
            "agent": self.name,
            "duplicate_groups": groups,
            "total_duplicates": len(duplicates),
            "unique_stories": len(groups)
        }
    
    @staticmethod
    def _group_duplicates(articles: List[Dict], duplicates: List[tuple]) -> List[List[Dict]]:
        """Group articles by duplicate relationships"""
        groups = []
        processed = set()
        
        for article in articles:
            if article['id'] in processed:
                continue
            
            # Find all duplicates for this article
            group = [article]
            processed.add(article['id'])
            
            for id1, id2, score in duplicates:
                if id1 == article['id'] and id2 not in processed:
                    dup_article = next((a for a in articles if a['id'] == id2), None)
                    if dup_article:
                        group.append(dup_article)
                        processed.add(id2)
                elif id2 == article['id'] and id1 not in processed:
                    dup_article = next((a for a in articles if a['id'] == id1), None)
                    if dup_article:
                        group.append(dup_article)
                        processed.add(id1)
            
            groups.append(group)
        
        return groups

class EntityExtractionAgent:
    """Agent responsible for extracting entities from articles"""
    
    def __init__(self, extractor):
        self.extractor = extractor
        self.name = "EntityExtractionAgent"
    
    def process(self, articles: List[Dict]) -> Dict:
        """Extract entities from articles"""
        all_entities = []
        entity_counts = {}
        
        for article in articles:
            text = article.get('title', '') + ' ' + article.get('content', '')
            entities = self.extractor.extract_entities(text)
            
            for entity in entities:
                all_entities.append({
                    'article_id': article['id'],
                    'entity': entity.text,
                    'type': entity.type,
                    'confidence': entity.confidence
                })
                
                key = f"{entity.text}:{entity.type}"
                entity_counts[key] = entity_counts.get(key, 0) + 1
        
        return {
            "agent": self.name,
            "entities_extracted": len(all_entities),
            "unique_entities": len(set(e['entity'] for e in all_entities)),
            "top_entities": sorted(entity_counts.items(), key=lambda x: x[1], reverse=True)[:10],
            "entities": all_entities
        }

class StockMapperAgent:
    """Agent responsible for mapping entities to stocks"""
    
    def __init__(self, mapper):
        self.mapper = mapper
        self.name = "StockMapperAgent"
    
    def process(self, entities: List[Dict]) -> Dict:
        """Map entities to affected stocks"""
        stock_impacts = []
        impact_summary = {}
        
        for entity_info in entities:
            # Create a mock entity object
            class Entity:
                def __init__(self, text, type_, conf):
                    self.text = text
                    self.type = type_
                    self.confidence = conf
            
            entity = Entity(entity_info['entity'], entity_info['type'], entity_info['confidence'])
            impacts = self.mapper.map_stocks([entity], '')
            
            for impact in impacts:
                stock_impacts.append({
                    'article_id': entity_info['article_id'],
                    'stock': impact['symbol'],
                    'confidence': impact['confidence'],
                    'type': impact['type'],
                    'entity': impact['entity']
                })
                
                impact_summary[impact['symbol']] = impact_summary.get(impact['symbol'], 0) + 1
        
        return {
            "agent": self.name,
            "stock_impacts": stock_impacts,
            "affected_stocks": len(set(s['stock'] for s in stock_impacts)),
            "most_impacted": sorted(impact_summary.items(), key=lambda x: x[1], reverse=True)[:5]
        }

class QueryAnalyzerAgent:
    """Agent responsible for analyzing queries"""
    
    def __init__(self, query_engine):
        self.query_engine = query_engine
        self.name = "QueryAnalyzerAgent"
    
    def process(self, query: str) -> Dict:
        """Analyze and process query"""
        parsed = self.query_engine.parse_query(query)
        
        return {
            "agent": self.name,
            "query": query,
            "intent": parsed['intent'],
            "entities": parsed['entities'],
            "query_type": parsed['type'],
            "suggested_filters": self._suggest_filters(parsed)
        }
    
    @staticmethod
    def _suggest_filters(parsed: Dict) -> List[str]:
        """Suggest filters based on parsed query"""
        filters = []
        
        if parsed['type'] == 'company':
            filters.append("Filter by company entities")
        elif parsed['type'] == 'sector':
            filters.append("Filter by sector tags")
        elif parsed['type'] == 'regulatory':
            filters.append("Filter by regulatory entities")
        
        if parsed['intent'] == 'impact':
            filters.append("Sort by impact severity")
        
        return filters

class RAGRetrieverAgent:
    """Agent responsible for RAG-based retrieval"""
    
    def __init__(self, rag_system):
        self.rag_system = rag_system
        self.name = "RAGRetrieverAgent"
    
    def process(self, query: str, articles: List[Dict]) -> Dict:
        """Retrieve relevant articles using RAG"""
        context = self.query_engine.augment_query_context(query)
        
        return {
            "agent": self.name,
            "query": query,
            "retrieved_articles": context['relevant_documents'],
            "context_summary": context['context_summary'],
            "retrieval_score": len(context['relevant_documents']) / max(len(articles), 1)
        }

class MultiAgentOrchestrator:
    """Orchestrates multiple agents in a workflow"""
    
    def __init__(self, deduplicator, extractor, mapper, query_engine, rag_system):
        self.agents = {
            AgentType.DEDUPLICATION: DeduplicationAgent(deduplicator),
            AgentType.ENTITY_EXTRACTION: EntityExtractionAgent(extractor),
            AgentType.STOCK_MAPPER: StockMapperAgent(mapper),
            AgentType.QUERY_ANALYZER: QueryAnalyzerAgent(query_engine),
            AgentType.RAG_RETRIEVER: RAGRetrieverAgent(rag_system)
        }
        self.message_queue = []
    
    def process_articles(self, articles: List[Dict]) -> Dict:
        """Run full processing pipeline"""
        results = {}
        
        # Step 1: Deduplication
        dedup_result = self.agents[AgentType.DEDUPLICATION].process(articles)
        results['deduplication'] = dedup_result
        
        # Get unique articles for further processing
        unique_articles = [group[0] for group in dedup_result['duplicate_groups']]
        
        # Step 2: Entity Extraction
        entity_result = self.agents[AgentType.ENTITY_EXTRACTION].process(unique_articles)
        results['entities'] = entity_result
        
        # Step 3: Stock Mapping
        stock_result = self.agents[AgentType.STOCK_MAPPER].process(entity_result['entities'])
        results['stock_impacts'] = stock_result
        
        return results
    
    def process_query(self, query: str, articles: List[Dict]) -> Dict:
        """Process a user query"""
        results = {}
        
        # Step 1: Analyze query
        query_result = self.agents[AgentType.QUERY_ANALYZER].process(query)
        results['query_analysis'] = query_result
        
        # Step 2: RAG retrieval (if needed)
        if query_result['entities'] or query_result['intent'] != 'general':
            rag_result = self.agents[AgentType.RAG_RETRIEVER].process(query, articles)
            results['rag_retrieval'] = rag_result
        
        return results
