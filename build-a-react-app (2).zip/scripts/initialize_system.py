#!/usr/bin/env python3
"""
Initialize Financial News Intelligence System
Creates necessary database schemas and loads sample data
"""

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

def init_database():
    """Initialize SQLite database with required schemas"""
    db_path = Path("data/financial_news.db")
    db_path.parent.mkdir(exist_ok=True)
    
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    # News articles table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS articles (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        source TEXT NOT NULL,
        published_date TIMESTAMP,
        created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        embedding BLOB,
        is_duplicate BOOLEAN DEFAULT 0,
        canonical_article_id TEXT
    )
    """)
    
    # Entities extracted from articles
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS entities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        article_id TEXT NOT NULL,
        entity_text TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        confidence REAL,
        FOREIGN KEY (article_id) REFERENCES articles(id)
    )
    """)
    
    # Stock impact mappings
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_impacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        article_id TEXT NOT NULL,
        stock_symbol TEXT NOT NULL,
        impact_type TEXT NOT NULL,
        confidence REAL,
        sector TEXT,
        FOREIGN KEY (article_id) REFERENCES articles(id)
    )
    """)
    
    # Query history
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS queries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query_text TEXT NOT NULL,
        executed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        results_count INTEGER
    )
    """)
    
    conn.commit()
    return conn

def load_sample_data(conn):
    """Load sample financial news articles"""
    cursor = conn.cursor()
    
    sample_articles = [
        {
            "id": "N1",
            "title": "HDFC Bank announces 15% dividend, board approves stock buyback",
            "content": "HDFC Bank's board has approved a 15% dividend and authorized a stock buyback program. The move reflects strong capital position and commitment to shareholders.",
            "source": "BSE India",
            "published_date": datetime.now() - timedelta(hours=2)
        },
        {
            "id": "N2",
            "title": "RBI raises repo rate by 25bps to 6.75%, citing inflation concerns",
            "content": "The Reserve Bank of India increased the repo rate by 25 basis points to 6.75% in response to persistent inflation concerns. This is an unexpected move that signals a hawkish stance.",
            "source": "RBI Official",
            "published_date": datetime.now() - timedelta(hours=1)
        },
        {
            "id": "N3",
            "title": "ICICI Bank opens 500 new branches across Tier-2 cities",
            "content": "ICICI Bank announced expansion of its branch network with 500 new locations in Tier-2 cities, targeting underserved markets for financial inclusion.",
            "source": "NSE India",
            "published_date": datetime.now() - timedelta(hours=3)
        },
        {
            "id": "N4",
            "title": "Banking sector NPAs decline to 5-year low, credit growth at 16%",
            "content": "Banking sector shows strong performance with Non-Performing Assets declining to 5-year lows and credit growth accelerating to 16% annually.",
            "source": "Financial Times",
            "published_date": datetime.now() - timedelta(hours=4)
        },
        {
            "id": "N5",
            "title": "Central bank increases policy rate 25 bps in surprise inflation fight",
            "content": "In an unexpected move, the central bank raised the policy rate by 25 basis points to combat rising inflation pressures in the economy.",
            "source": "Reuters",
            "published_date": datetime.now() - timedelta(minutes=30)
        },
        {
            "id": "N6",
            "title": "Tech sector sees 12% surge on AI investment announcements",
            "content": "Technology stocks rallied on multiple announcements of increased AI and ML investments by major companies.",
            "source": "Economic Times",
            "published_date": datetime.now() - timedelta(hours=5)
        }
    ]
    
    for article in sample_articles:
        cursor.execute("""
        INSERT OR IGNORE INTO articles (id, title, content, source, published_date)
        VALUES (?, ?, ?, ?, ?)
        """, (
            article["id"],
            article["title"],
            article["content"],
            article["source"],
            article["published_date"]
        ))
    
    conn.commit()
    print(f"Loaded {len(sample_articles)} sample articles")

if __name__ == "__main__":
    conn = init_database()
    load_sample_data(conn)
    conn.close()
    print("Database initialized successfully!")
