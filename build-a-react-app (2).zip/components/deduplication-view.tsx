"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function DeduplicationView({ articles }) {
  const [duplicateGroups, setDuplicateGroups] = useState([])
  const [loading, setLoading] = useState(false)

  const checkDuplicates = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/dedup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ articles }),
      })
      const data = await response.json()
      setDuplicateGroups(data.duplicate_groups || [])
    } catch (error) {
      console.error("Deduplication failed:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-100">Deduplication Analysis</CardTitle>
          <CardDescription>Identify and consolidate duplicate articles</CardDescription>
        </CardHeader>
        <CardContent>
          <button
            onClick={checkDuplicates}
            disabled={loading}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded disabled:bg-slate-600"
          >
            {loading ? "Analyzing..." : "Analyze Duplicates"}
          </button>
        </CardContent>
      </Card>

      {duplicateGroups.length > 0 && (
        <div className="space-y-4">
          {duplicateGroups.map((group, idx) => (
            <Card key={idx} className="bg-slate-800 border-slate-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm text-slate-100">Story Group {idx + 1}</CardTitle>
                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-400/30">{group.length} articles</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {group.map((article, i) => (
                    <div key={i} className="p-3 rounded bg-slate-700/50 border border-slate-600">
                      <p className="text-sm font-semibold text-slate-100 line-clamp-1">{article.title}</p>
                      <p className="text-xs text-slate-400 mt-1">{article.source}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
