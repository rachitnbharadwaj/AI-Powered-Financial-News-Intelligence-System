"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function AdvancedSearch({ articles }) {
  const [query, setQuery] = useState("")
  const [filters, setFilters] = useState({
    entities: [],
    sources: [],
    date_from: "",
    date_to: "",
  })
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleSearch = async () => {
    if (!query.trim()) return

    setLoading(true)
    try {
      const response = await fetch("/api/search/advanced", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, filters, limit: 10 }),
      })
      const data = await response.json()
      setResults(data)
    } catch (error) {
      console.error("Search failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const toggleEntity = (entity: string) => {
    setFilters((prev) => ({
      ...prev,
      entities: prev.entities.includes(entity) ? prev.entities.filter((e) => e !== entity) : [...prev.entities, entity],
    }))
  }

  const entities = ["HDFC Bank", "ICICI Bank", "SBI", "Banking", "RBI"]
  const sources = ["BSE India", "NSE India", "RBI Official", "Financial Times"]

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-100">Advanced Search</CardTitle>
          <CardDescription>Multi-filter semantic search with relevance ranking</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-slate-400 mb-2 block">Search Query</label>
            <div className="flex gap-2">
              <Input
                placeholder="Enter search query..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="bg-slate-700 border-slate-600 text-slate-100"
              />
              <Button onClick={handleSearch} disabled={loading} className="bg-cyan-600 hover:bg-cyan-500">
                {loading ? "Searching..." : "Search"}
              </Button>
            </div>
          </div>

          <div>
            <label className="text-sm text-slate-400 mb-2 block">Filter by Entity</label>
            <div className="flex flex-wrap gap-2">
              {entities.map((entity) => (
                <button
                  key={entity}
                  onClick={() => toggleEntity(entity)}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    filters.entities.includes(entity)
                      ? "bg-cyan-600 text-white"
                      : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                  }`}
                >
                  {entity}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-slate-400 mb-2 block">From Date</label>
              <Input
                type="date"
                value={filters.date_from}
                onChange={(e) => setFilters((prev) => ({ ...prev, date_from: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-slate-100"
              />
            </div>
            <div>
              <label className="text-sm text-slate-400 mb-2 block">To Date</label>
              <Input
                type="date"
                value={filters.date_to}
                onChange={(e) => setFilters((prev) => ({ ...prev, date_to: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-slate-100"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {results && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-100">
              Search Results
              <Badge className="ml-3 bg-cyan-500/20 text-cyan-400">{results.results_count}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {results.results?.map((article, idx) => (
              <div key={idx} className="p-4 rounded bg-slate-700/50 border border-slate-600">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-slate-100">{article.title}</h3>
                    <p className="text-sm text-slate-400 mt-2">{article.content.substring(0, 150)}...</p>
                  </div>
                  <Badge className="ml-3 bg-emerald-500/20 text-emerald-400">
                    {(article.relevance_score * 100).toFixed(0)}%
                  </Badge>
                </div>
                <div className="flex gap-2 mt-3 text-xs">
                  <span className="px-2 py-1 bg-slate-600 text-slate-300 rounded">{article.source}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
