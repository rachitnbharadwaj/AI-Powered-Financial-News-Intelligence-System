"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AgentMonitor({ articles }) {
  const [pipelineResult, setPipelineResult] = useState(null)
  const [loading, setLoading] = useState(false)

  const runAgentPipeline = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/agents/process", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ articles }),
      })
      const data = await response.json()
      setPipelineResult(data)
    } catch (error) {
      console.error("Pipeline execution failed:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-100">Multi-Agent Pipeline</CardTitle>
          <CardDescription>Execute coordinated agents for complete article analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <button
            onClick={runAgentPipeline}
            disabled={loading}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded disabled:bg-slate-600"
          >
            {loading ? "Running Pipeline..." : "Execute Agent Pipeline"}
          </button>
        </CardContent>
      </Card>

      {pipelineResult && (
        <>
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-slate-100">Pipeline Results</CardTitle>
              <Badge
                className={`${pipelineResult.pipeline_status === "completed" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"}`}
              >
                {pipelineResult.pipeline_status}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded bg-slate-700/50">
                  <p className="text-xs text-slate-400">Unique Stories</p>
                  <p className="text-2xl font-bold text-cyan-400">{pipelineResult.summary?.unique_stories}</p>
                </div>
                <div className="p-3 rounded bg-slate-700/50">
                  <p className="text-xs text-slate-400">Total Entities</p>
                  <p className="text-2xl font-bold text-emerald-400">{pipelineResult.summary?.total_entities}</p>
                </div>
                <div className="p-3 rounded bg-slate-700/50">
                  <p className="text-xs text-slate-400">Affected Stocks</p>
                  <p className="text-2xl font-bold text-purple-400">{pipelineResult.summary?.affected_stocks}</p>
                </div>
                <div className="p-3 rounded bg-slate-700/50">
                  <p className="text-xs text-slate-400">Avg Relevance</p>
                  <p className="text-2xl font-bold text-amber-400">{pipelineResult.summary?.avg_relevance_score}</p>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-semibold text-slate-100">Agents Executed:</p>
                {pipelineResult.agents_executed?.map((agent, idx) => (
                  <div key={idx} className="p-3 rounded bg-slate-700/50 border border-slate-600">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-sm text-slate-300">{agent.name}</span>
                      <Badge className="bg-emerald-500/20 text-emerald-400">{agent.status}</Badge>
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      {Object.entries(agent)
                        .filter(([k]) => k !== "name" && k !== "status")
                        .map(([k, v]) => `${k}: ${v}`)
                        .join(" • ")}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
