"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function EntityViewer({ articles }) {
  const [entities, setEntities] = useState([])
  const [impacts, setImpacts] = useState([])
  const [selectedEntity, setSelectedEntity] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchEntitiesAndImpacts()
  }, [articles])

  const fetchEntitiesAndImpacts = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/entities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ articles }),
      })
      const data = await response.json()
      setEntities(data.entities || [])
      setImpacts(data.impacts || [])
    } catch (error) {
      console.error("Failed to fetch entities:", error)
    } finally {
      setLoading(false)
    }
  }

  const entityColors = {
    Company: "bg-blue-500/20 text-blue-400 border-blue-400/30",
    Sector: "bg-purple-500/20 text-purple-400 border-purple-400/30",
    Regulator: "bg-red-500/20 text-red-400 border-red-400/30",
    BasisPoints: "bg-amber-500/20 text-amber-400 border-amber-400/30",
    Percentage: "bg-emerald-500/20 text-emerald-400 border-emerald-400/30",
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Extracted Entities */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-100">Extracted Entities</CardTitle>
          <CardDescription>Financial entities identified in articles</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-slate-400">Loading entities...</p>
          ) : (
            <div className="space-y-3">
              {entities.length > 0 ? (
                entities.map((entity, idx) => (
                  <div
                    key={idx}
                    onClick={() => setSelectedEntity(entity)}
                    className="p-3 rounded bg-slate-700/50 border border-slate-600 hover:border-cyan-400 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-100">{entity.text}</span>
                      <Badge className={`border ${entityColors[entity.type] || "bg-slate-600 text-slate-300"}`}>
                        {entity.type}
                      </Badge>
                    </div>
                    <div className="text-xs text-slate-500 mt-1">
                      Confidence: {(entity.confidence * 100).toFixed(0)}%
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-400 text-sm">No entities extracted yet</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stock Impact Mapping */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-100">Stock Impact Mapping</CardTitle>
          <CardDescription>Market entities mapped to affected stocks</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-slate-400">Loading impacts...</p>
          ) : (
            <div className="space-y-3">
              {impacts.length > 0 ? (
                impacts.map((impact, idx) => (
                  <div key={idx} className="p-3 rounded bg-slate-700/50 border border-slate-600">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-slate-100">{impact.symbol}</span>
                      <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-400/30">{impact.type}</Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="text-slate-400">
                        Confidence: <span className="text-cyan-400">{(impact.confidence * 100).toFixed(0)}%</span>
                      </div>
                      <div className="text-slate-400">
                        Entity: <span className="text-cyan-400">{impact.entity}</span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-400 text-sm">No stock impacts identified</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
