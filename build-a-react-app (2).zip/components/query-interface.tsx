"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function QueryInterface({ articles }) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleQuery = async (e) => {
    e.preventDefault()
    if (!query.trim()) return

    setLoading(true)
    try {
      const response = await fetch("/api/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      })
      const data = await response.json()
      setResults(data)
    } catch (error) {
      console.error("Query failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const exampleQueries = ["HDFC Bank news", "Banking sector update", "RBI policy changes", "Interest rate impact"]

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-100">Context-Aware Query System</CardTitle>
          <CardDescription>Search financial news with intelligent context expansion</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleQuery} className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Ask about companies, sectors, or regulatory changes..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="bg-slate-700 border-slate-600 text-slate-100 placeholder:text-slate-500"
              />
              <Button type="submit" disabled={loading} className="bg-cyan-600 hover:bg-cyan-500 text-white">
                {loading ? "Searching..." : "Search"}
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-sm text-slate-400">Example queries:</p>
              <div className="flex flex-wrap gap-2">
                {exampleQueries.map((example) => (
                  <button
                    key={example}
                    onClick={() => setQuery(example)}
                    className="px-3 py-1 text-sm rounded bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors"
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      {results && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-100">
              Query Results
              <Badge className="ml-2 bg-cyan-500/20 text-cyan-400 border-cyan-400/30">{results.count} results</Badge>
            </CardTitle>
            <CardDescription>
              Query Type: <span className="text-cyan-400 capitalize">{results.query_type}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {results.articles && results.articles.length > 0 ? (
                results.articles.map((article) => (
                  <div key={article.id} className="p-4 rounded bg-slate-700/50 border border-slate-600">
                    <h3 className="font-semibold text-slate-100 mb-2">{article.title}</h3>
                    <p className="text-sm text-slate-400 mb-3">{article.content.substring(0, 200)}...</p>
                    <div className="flex gap-2 text-xs">
                      <span className="px-2 py-1 bg-slate-600 text-slate-300 rounded">{article.source}</span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-400">No matching articles found</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
