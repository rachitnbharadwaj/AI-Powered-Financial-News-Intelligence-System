"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function NewsBoard({ articles, onSelectArticle }) {
  const [sortBy, setSortBy] = useState("recent")

  const sortedArticles = [...articles].sort((a, b) => {
    if (sortBy === "recent") {
      return new Date(b.published_date) - new Date(a.published_date)
    }
    return 0
  })

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now - date

    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
    return date.toLocaleDateString()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Real-Time News Feed</h2>
          <p className="text-sm text-muted-foreground mt-1">Latest financial news and market updates</p>
        </div>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="px-3 py-2 rounded-md bg-card border border-border text-foreground text-sm font-medium transition-colors hover:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
        >
          <option value="recent">Most Recent</option>
          <option value="relevant">Most Relevant</option>
        </select>
      </div>

      <div className="grid gap-4">
        {sortedArticles.map((article) => (
          <Card
            key={article.id}
            className="bg-card border-border hover:border-primary transition-all duration-200 hover:shadow-lg hover:shadow-primary/5 cursor-pointer group"
            onClick={() => onSelectArticle(article)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <CardTitle className="text-base text-foreground group-hover:text-primary transition-colors line-clamp-2">
                    {article.title}
                  </CardTitle>
                  <CardDescription className="text-muted-foreground mt-2 line-clamp-2">
                    {article.content.substring(0, 150)}...
                  </CardDescription>
                </div>
                {article.is_duplicate && (
                  <Badge variant="outline" className="shrink-0 bg-amber-500/10 text-amber-600 border-amber-500/20">
                    Duplicate
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="flex items-center justify-between text-sm flex-wrap gap-3">
              <div className="flex gap-3 items-center">
                <span className="px-2.5 py-1 rounded bg-primary/10 text-primary text-xs font-medium">
                  {article.source}
                </span>
                <span className="text-muted-foreground text-xs">{formatDate(article.published_date)}</span>
              </div>
              <Badge variant="outline" className="text-primary border-primary/30 hover:bg-primary/5">
                Read More →
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>

      {sortedArticles.length === 0 && (
        <div className="text-center py-16 bg-card/50 rounded-lg border border-border">
          <p className="text-lg font-medium text-foreground mb-2">No articles loaded</p>
          <p className="text-sm text-muted-foreground">Initialize the system to load sample financial news</p>
        </div>
      )}
    </div>
  )
}
