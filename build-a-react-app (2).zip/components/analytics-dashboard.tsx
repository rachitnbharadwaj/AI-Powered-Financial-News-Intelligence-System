"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AnalyticsDashboard() {
  const [analytics, setAnalytics] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAnalytics()
  }, [])

  const fetchAnalytics = async () => {
    try {
      const response = await fetch("/api/analytics")
      const data = await response.json()
      setAnalytics(data)
    } catch (error) {
      console.error("Failed to fetch analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="text-muted-foreground">Loading analytics...</div>
  }

  if (!analytics) {
    return <div className="text-muted-foreground">Failed to load analytics</div>
  }

  const metrics = [
    {
      label: "Articles Indexed",
      value: analytics.system_metrics.total_articles_indexed,
      color: "from-primary to-cyan-500",
    },
    {
      label: "Unique Stories",
      value: analytics.system_metrics.unique_stories_identified,
      color: "from-accent to-emerald-500",
    },
    {
      label: "Dedup Score",
      value: (analytics.system_metrics.average_deduplication_score * 100).toFixed(0) + "%",
      color: "from-amber-500 to-orange-500",
    },
    {
      label: "Entities Found",
      value: analytics.system_metrics.unique_entities_discovered,
      color: "from-purple-500 to-pink-500",
    },
    {
      label: "Stock Impacts",
      value: analytics.system_metrics.total_stock_impacts_mapped,
      color: "from-rose-500 to-red-500",
    },
  ]

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {metrics.map((metric, idx) => (
          <Card key={idx} className="bg-card border-border overflow-hidden">
            <div className={`h-1 bg-gradient-to-r ${metric.color}`}></div>
            <CardContent className="pt-6">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-2">{metric.label}</p>
              <p className="text-3xl font-bold text-foreground">{metric.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">Agent Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(analytics.agent_performance).map(([agent, metrics]: any) => (
              <div
                key={agent}
                className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/50 hover:border-border transition-colors"
              >
                <span className="text-sm font-semibold text-foreground capitalize">{agent.replace(/_/g, " ")}</span>
                <div className="flex gap-6 text-sm">
                  <div className="text-right">
                    <span className="text-muted-foreground text-xs uppercase tracking-wider">Accuracy</span>
                    <div className="text-accent font-semibold">{(metrics.accuracy * 100).toFixed(0)}%</div>
                  </div>
                  <div className="text-right">
                    <span className="text-muted-foreground text-xs uppercase tracking-wider">Response Time</span>
                    <div className="text-primary font-semibold">{metrics.avg_time_ms}ms</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg text-foreground">Top Entities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analytics.top_entities.map((entity, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                >
                  <span className="text-sm font-medium text-foreground">{entity.entity}</span>
                  <Badge className="bg-primary/10 text-primary border-primary/30">{entity.count} mentions</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg text-foreground">Most Impacted Stocks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analytics.top_stocks.map((stock, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                >
                  <span className="text-sm font-mono font-semibold text-foreground">{stock.symbol}</span>
                  <div className="flex gap-3 text-sm">
                    <span className="text-muted-foreground">{stock.mention_count} mentions</span>
                    <span className="text-accent font-semibold">{(stock.impact_score * 100).toFixed(0)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">Query Type Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(analytics.query_metrics.query_types_distribution).map(([type, percentage]: any) => (
              <div key={type} className="flex items-center gap-4">
                <span className="text-sm font-medium text-foreground capitalize w-28">{type}</span>
                <div className="flex-1 bg-background rounded-full h-3 overflow-hidden border border-border/50">
                  <div
                    className="bg-gradient-to-r from-primary to-accent h-full transition-all duration-500"
                    style={{ width: `${percentage * 100}%` }}
                  ></div>
                </div>
                <span className="text-sm font-semibold text-foreground w-12 text-right">
                  {(percentage * 100).toFixed(0)}%
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
